SHOPMMO.BM - FULL FIXED SOURCE

Upload index.html to the root of your GitHub repository and replace the existing index.html.

Fixes included:
- Safe Supabase logout flow.
- Remote product loading follows Supabase Row Level Security visibility.
- Demo catalogue remains visible when the Supabase products table is empty.
- Existing local data arrays are initialized safely for older browser storage.
- Login returns to the marketplace home page.

Important:
This is the corrected front-end source based on the uploaded index.html. It does not turn demo/localStorage wallet, deposits, orders, chat, or refunds into a production payment system. Do not accept real deposits or process real payouts until trusted server-side functions and database policies are implemented and tested. The supplied Supabase schema creates new accounts as buyer by default; seller/admin roles must be assigned securely by an administrator.
